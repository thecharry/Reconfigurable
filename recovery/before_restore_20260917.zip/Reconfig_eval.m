function [Z,Jc1,Jc2,Jc,Jo,Jt,Jf] = Reconfig_eval(params,Ball,varargin)
% 策略已验证单轴能力。硬件纯轴理论上限另存于Z.Hardware。
% Jc6为共同尺度下的最弱单轴能力，不再代表六维内切球半径。
    [Z,Jc1,Jc2,Jc,Jo,Jt,Jf]=Policy_Reconfig_eval(params,Ball,varargin{:});
end
