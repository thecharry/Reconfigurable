function tests=test_policy_evaluation
    tests=functiontests(localfunctions);
end

function setupOnce(t)
    t.applyFixture(matlab.unittest.fixtures.PathFixture(fileparts(fileparts(mfilename('fullpath')))));
    t.TestData.p=struct('F_max',10,'T',0.4,'t_min',0.02,'Num',12);
    t.TestData.B=[eye(6),-eye(6)];
end

function testHardwareDoesNotImplyBoundGroupCapability(t)
    p=t.TestData.p;
    z=Reconfig_eval(p,t.TestData.B,0,false);
    verifyEqual(t,z.Hardware.axis_capacity,10*ones(6,2),'AbsTol',1e-8);
    % Each signed basis column occurs once: a nonzero pure even group is impossible.
    verifyEqual(t,nnz(z.Invocation.strict_equal_axis),0);
    verifyEqual(t,nnz(z.Invocation.axis_callable),0);
    verifyEqual(t,z.Jc,[0,0]);
end

function testPolicySwitchAndMinimumImpulseGaps(t)
    p=t.TestData.p; p.alloc_mode='joint_optimization';
    z=Reconfig_eval(p,t.TestData.B,0,false);
    verifyTrue(t,z.Invocation.policy_reconfigurable);
    verifyTrue(t,z.Invocation.reference_commands_callable);
    verifyEqual(t,z.Invocation.axis_capacity,10*ones(6,2),'AbsTol',2e-5);
    p.t_min=0.2; q=Reconfig_eval(p,t.TestData.B,0,false);
    verifyEqual(t,q.Hardware,z.Hardware);
    verifyTrue(t,q.Invocation.policy_reconfigurable);
    verifyFalse(t,q.Invocation.reference_commands_callable);
    % Positive direction capacity does not imply small commands are reachable.
    verifyEqual(t,q.Invocation.reference_pass_rate,0);
end

function testNoFalseReconfigurationFromPositiveScores(t)
    p=t.TestData.p; z=Reconfig_eval(p,t.TestData.B,0,false);
    z.Score=1; z.MetricRaw=ones(1,4); z=Reconfig_Status(z);
    verifyFalse(t,z.IsReconfig); verifyTrue(t,isnan(z.Score));
    p.alloc_mode='joint_optimization'; z=Reconfig_eval(p,t.TestData.B,0,false);
    z.MetricRaw=zeros(1,4); z=Reconfig_Status(z);
    verifyTrue(t,z.IsReconfig);
end

function testAllFaultsPreservesNominal(t)
    p=t.TestData.p; p.alloc_mode='joint_optimization';
    z=Reconfig_eval(p,t.TestData.B,12,false);
    verifyTrue(t,z.Hardware(1).reconfigurable);
    verifyEqual(t,z.Hardware(2).axis_capacity,zeros(6,2));
    verifyFalse(t,z.Invocation(2).policy_reconfigurable);
end

function testImpulseCancellationDoesNotCancelFirstMoment(t)
    p=struct('T',1,'t_min',0.02);
    M=zeros(6,2); M(1,:)=[1,-1];
    schedule=struct('intervals',{{[0,.5];[.5,1]}});
    q=Pulse_Schedule_Metrics(M,schedule,p,zeros(6,1),[]);
    verifyTrue(t,q.valid);
    verifyEqual(t,q.end_cross_impulse,zeros(6,1),'AbsTol',1e-12);
    verifyEqual(t,q.first_moment(1),.25,'AbsTol',1e-12);
    verifyEqual(t,q.peak_cross_force,1);
    verifyEqual(t,q.peak_prefix_impulse(1),.5);
end

function testActualScheduleChecksHardwareLimits(t)
    p=struct('T',1,'t_min',.1); M=zeros(6,1); M(1)=1;
    for intervals={{[0,.05]},{[0,.4;.3,.7]},{[0,1.1]}}
        q=Pulse_Schedule_Metrics(M,struct('intervals',{intervals{1}}),p,zeros(6,1),[]);
        verifyFalse(t,q.valid);
    end
    q=Pulse_Schedule_Metrics(M,struct('intervals',{{[0,.2]}}),p,zeros(6,1),1);
    verifyFalse(t,q.valid);
    % Adjacent segments are one continuous firing, not two short pulses.
    q=Pulse_Schedule_Metrics(M,struct('intervals',{{[0,.06;.06,.12]}}),p,zeros(6,1),[]);
    verifyTrue(t,q.valid);
end

function testHistoricalCoverageAndIndependentWitnesses(t)
    p=t.TestData.p;
    x=[.2,0,0,pi/4,.6,-.2,pi/2,pi/4,.6,.2,3*pi/2,pi/4];
    B=zeros(6,12);
    for k=1:3
        y=x(4*k-3); zz=x(4*k-2); a=x(4*k-1); b=x(4*k);
        r=[2,2,-2,-2;y,-y,y,-y;zz,-zz,zz,-zz];
        d=[cos(b)*[-1,-1,1,1];sin(b)*cos(a)*[1,-1,1,-1];sin(b)*sin(a)*[1,-1,1,-1]];
        B(:,4*k-3:4*k)=[d;cross(r,d)];
    end
    z=Reconfig_eval(p,B,1,false);
    verifyEqual(t,sum(arrayfun(@(v)nnz(v.strict_equal_axis),z.Invocation)),152);
    for f=1:13
        inv=z.Invocation(f); upper=z.Hardware(f).axis_capacity;
        verifyLessThanOrEqual(t,inv.axis_capacity,upper+1e-5);
        for k=1:12
            w=inv.axis_witness{k}; if isempty(w), continue; end
            q=Pulse_Schedule_Metrics(10*B,w.schedule,p,w.command,z.FaultSets{f});
            verifyTrue(t,q.valid);
            verifyEqual(t,q.average,w.actual,'AbsTol',1e-10);
        end
    end
end

function testSubsetPlotDataPreservesPolicyAndHardware(t)
    p=t.TestData.p; p.alloc_mode='joint_optimization';
    layouts=struct('name','测试','B',t.TestData.B);
    a=RCPlotter.policyComparisonData(p,layouts,{[],1});
    verifySize(t,a.Data,[2,numel(a.ColumnNames)]);
    verifyEqual(t,numel(a.Evaluations{1}.Invocation),2);
    verifyEqual(t,numel(a.Evaluations{1}.Hardware),2);
    verifyEqual(t,a.Evaluations{1}.FaultSets,{[];1});
    b=RCPlotter.reconfigSummaryData(p,layouts,0);
    verifyEqual(t,b.Data{1,4},1);
    fig=uifigure('Visible','off'); c=onCleanup(@()delete(fig)); %#ok<NASGU>
    grid=uigridlayout(fig,[1,2]); axesList=[uiaxes(grid),uiaxes(grid)];
    RCPlotter.plotControlEnvelopeComparison(axesList(1),axesList(2),p,layouts,[]);
    verifyEqual(t,numel(findobj(axesList(1),'Type','bar')),2);
end
