function [Z,Jc1,Jc2,Jc,Jo,Jt,Jf] = Policy_Reconfig_eval(params,Ball,maxFaults,combined)
% Verified policy endpoints, not a continuous envelope or global optimum.
% Hardware: independent continuous duty in [0,1], all non-target rows zero.
    if nargin<3 || isempty(maxFaults), maxFaults=1; end
    if nargin<4 || isempty(combined), combined=true; end
    n=size(Ball,2);
    validateattributes(Ball,{'numeric'},{'size',[6,n],'finite'});
    validateattributes(maxFaults,{'numeric'},{'scalar','integer','>=',0,'<=',n});
    validateattributes(params.T,{'numeric'},{'scalar','positive','finite'});
    validateattributes(params.t_min,{'numeric'},{'scalar','nonnegative','finite'});
    validateattributes(params.F_max,{'numeric'},{'scalar','positive','finite'});
    names={'T','t_min','F_max','alloc_mode','allocation_strategy','strict_group_contract', ...
        'strict_contract_matrix','evaluation_reference_length','evaluation_reference_fraction'};
    p=struct();
    for k=1:numel(names)
        if isfield(params,names{k}), p.(names{k})=params.(names{k}); end
    end
    p.Num=n;
    p.alloc_mode=option(p,'alloc_mode','synchronous_time_division');
    if strcmp(option(p,'allocation_strategy','primary_backup'),'joint_optimization')
        p.alloc_mode='joint_optimization';
    end
    if isfield(p,'strict_contract_matrix') && ~isequal(p.strict_contract_matrix,Ball)
        if isfield(p,'strict_group_contract'), p=rmfield(p,'strict_group_contract'); end
    end
    L=option(p,'evaluation_reference_length',2);
    fraction=option(p,'evaluation_reference_fraction',0.2);
    validateattributes(L,{'numeric'},{'scalar','positive','finite'});
    validateattributes(fraction,{'numeric'},{'scalar','positive','finite'});
    ref=p.F_max*[ones(3,1);L*ones(3,1)];
    key=struct('params',p,'B',Ball,'faults',maxFaults,'combined',combined);
    persistent cache
    for k=1:numel(cache)
        if isequaln(cache(k).key,key)
            Z=cache(k).value; Jc1=Z.Jc; Jc2=Z.JcMax; Jc=Z.Jc6;
            Jo=Z.Jo; Jt=Z.Jt; Jf=Z.Jf; return;
        end
    end
    faultsets={[]};
    if maxFaults>0
        sets=nchoosek(1:n,maxFaults);
        faultsets=[faultsets;mat2cell(sets,ones(size(sets,1),1),maxFaults)];
    end
    M=p.F_max*Ball; count=numel(faultsets);
    Jc1=zeros(count,2); Jc2=Jc1; Jc=zeros(count,1); Jo=Jc; Jt=Jc; Jf=Jc;
    template=struct('axis_callable',false(6,2),'strict_axis',false(6,2), ...
        'axis_capacity',zeros(6,2),'axis_min_verified',nan(6,2), ...
        'axis_witness',{cell(6,2)},'force_capacity',0,'torque_capacity',0, ...
        'worst_capacity',0,'policy_reconfigurable',false,'strictly_reconfigurable',false, ...
        'uses_impulse_margin_fallback',false,'worst_reference_quality',0, ...
        'reference_commands_callable',false,'reference_pass_rate',0, ...
        'reference_error',[],'reference_schedule_valid',[], ...
        'strict_equal_axis',false(6,2),'strict_equal_capacity',zeros(6,2), ...
        'peak_cross_force',0,'peak_cross_torque',0,'end_cross_force_impulse',0, ...
        'end_cross_torque_impulse',0,'peak_cross_force_impulse',0, ...
        'peak_cross_torque_impulse',0,'cross_force_first_moment',0, ...
        'cross_torque_first_moment',0,'energy_valid',false);
    Invocation=repmat(template,count,1);
    Hardware=repmat(struct('axis_capacity',zeros(6,2),'force_capacity',0, ...
        'torque_capacity',0,'worst_capacity',0,'reconfigurable',false),count,1);
    bits=zeros(n,0);
    for g=2:2:min(6,n)
        groups=nchoosek(1:n,g); block=zeros(n,size(groups,1));
        for j=1:size(groups,1), block(groups(j,:),j)=1; end
        bits=[bits,block]; %#ok<AGROW>
    end
    W=(M./ref)*bits; errors=zeros(count,1);
    for f=1:count
        faults=faultsets{f}; healthy=setdiff(1:n,faults); inv=template;
        H=hardwareAxes(M,healthy,ref);
        Hardware(f).axis_capacity=H;
        Hardware(f).force_capacity=min(H(1:3,:),[],'all');
        Hardware(f).torque_capacity=min(H(4:6,:),[],'all');
        Hardware(f).worst_capacity=min(H./ref,[],'all');
        Hardware(f).reconfigurable=all(H./ref>1e-8,'all');
        V=W(:,all(bits(faults,:)==0,1));
        for axis=1:6
            off=setdiff(1:6,axis); pure=max(abs(V(off,:)),[],1)<=1e-9;
            for dir=1:2
                s=2*dir-3; cap=max([0,s*V(axis,pure)]);
                inv.strict_equal_capacity(axis,dir)=cap*ref(axis);
                inv.strict_equal_axis(axis,dir)=cap>=1e-5-1e-9;
                % Actual calls, then re-call at selected-group maximum/minimum
                % endpoints. Switching is non-monotone: no false bisection proof.
                amplitudes=unique([fraction*ref(axis),H(axis,dir)*[1 .75 .5 .25 .1 .05 .01]]);
                endpoints=[];
                for a=reshape(amplitudes(amplitudes>1e-7),1,[])
                    [ok,strict,q,info]=probe(a,axis,s,M,faults,p,ref);
                    inv=keepWitness(inv,ok,strict,q,info,a,axis,dir);
                    strategy=info.axis_strategy{1+(axis>3),mod(axis-1,3)+1};
                    if isstruct(strategy) && isfield(strategy,'duty') && any(strategy.duty>1e-12)
                        d=strategy.duty(strategy.duty>1e-12);
                        endpoints=[endpoints,a/max(d),a*(p.t_min/p.T)/min(d)]; %#ok<AGROW>
                    end
                end
                endpoints=unique(endpoints(endpoints>1e-7 & endpoints<=H(axis,dir)*(1+1e-7)));
                for a=reshape(endpoints,1,[])
                    [ok,strict,q,info]=probe(a,axis,s,M,faults,p,ref);
                    inv=keepWitness(inv,ok,strict,q,info,a,axis,dir);
                end
            end
        end
        commands=[diag(fraction*ref),-diag(fraction*ref)];
        if combined
            for i=[1:3,7:9]
                for j=[4:6,10:12], commands(:,end+1)=commands(:,i)+commands(:,j); end %#ok<AGROW>
            end
        end
        err=zeros(size(commands,2),1); consumption=err;
        good=false(size(err)); valid=good;
        for c=1:size(commands,2)
            cmd=commands(:,c);
            [pulse,info]=Thruster_invocation(cmd(1:3),cmd(4:6),M,faults,p);
            q=Pulse_Schedule_Metrics(M,info.schedule,p,cmd,faults);
            err(c)=norm((cmd-q.average)./ref)/norm(cmd./ref);
            valid(c)=q.valid && max(abs(q.pulse-pulse))<=1e-8;
            good(c)=valid(c) && err(c)<=1e-5; consumption(c)=sum(pulse);
            if c<=12
                inv.peak_cross_force=max(inv.peak_cross_force,q.peak_cross_force);
                inv.peak_cross_torque=max(inv.peak_cross_torque,q.peak_cross_torque);
                inv.end_cross_force_impulse=max(inv.end_cross_force_impulse,norm(q.end_cross_impulse(1:3)));
                inv.end_cross_torque_impulse=max(inv.end_cross_torque_impulse,norm(q.end_cross_impulse(4:6)));
                inv.peak_cross_force_impulse=max(inv.peak_cross_force_impulse,norm(q.peak_prefix_impulse(1:3)));
                inv.peak_cross_torque_impulse=max(inv.peak_cross_torque_impulse,norm(q.peak_prefix_impulse(4:6)));
                inv.cross_force_first_moment=max(inv.cross_force_first_moment,norm(q.cross_first_moment(1:3)));
                inv.cross_torque_first_moment=max(inv.cross_torque_first_moment,norm(q.cross_first_moment(4:6)));
            end
        end
        inv.force_capacity=min(inv.axis_capacity(1:3,:),[],'all');
        inv.torque_capacity=min(inv.axis_capacity(4:6,:),[],'all');
        inv.worst_capacity=min(inv.axis_capacity./ref,[],'all');
        inv.policy_reconfigurable=all(inv.axis_callable,'all');
        inv.strictly_reconfigurable=all(inv.strict_axis,'all');
        inv.reference_commands_callable=all(good); inv.reference_pass_rate=mean(good);
        inv.reference_error=err; inv.reference_schedule_valid=valid;
        inv.worst_reference_quality=max(0,1-max(err)); inv.energy_valid=all(good);
        Invocation(f)=inv;
        Jc1(f,:)=[inv.force_capacity,inv.torque_capacity];
        Jc2(f,:)=[max(inv.axis_capacity(1:3,:),[],'all'),max(inv.axis_capacity(4:6,:),[],'all')];
        Jc(f)=inv.worst_capacity; Jo(f)=columnAngle(M(:,healthy)./ref);
        quality=max(0,1-err); quality(~valid)=0;
        Jt(f)=mean(quality); Jf(f)=mean(consumption); errors(f)=mean(err);
    end
    Z=struct('FaultSets',{faultsets},'Jc',Jc1,'JcMax',Jc2,'Jc6',Jc,'Jo',Jo,'Jt',Jt,'Jf',Jf, ...
        'Invocation',Invocation,'Hardware',Hardware,'ReferenceScale',ref, ...
        'ReferenceFraction',fraction,'PolicyMode',p.alloc_mode, ...
        'CapabilityMeaning','verified single-axis endpoints; not insphere, envelope or global optimum', ...
        'PolicyRelativeTolerance',1e-5,'InstantaneousNormalizedTolerance',1e-9, ...
        'Raw',struct('JcForce',Jc1(:,1),'JcTorque',Jc1(:,2),'Jc6',Jc, ...
        'JoAngle',Jo,'JtQuality',Jt,'JtError',errors,'JfPulse',Jf));
    entry=struct('key',key,'value',Z);
    if isempty(cache), cache=entry; else, cache(end+1)=entry; end
    if numel(cache)>12, cache=cache(end-11:end); end
end

function H=hardwareAxes(M,healthy,ref)
    H=zeros(6,2); if isempty(healthy), return; end
    A=M(:,healthy)./ref;
    opts=optimoptions('linprog','Display','none','ConstraintTolerance',1e-9);
    for k=1:6
        off=setdiff(1:6,k);
        for d=1:2
            s=2*d-3;
            [u,~,flag]=linprog(-s*A(k,:),[],[],A(off,:),zeros(5,1), ...
                zeros(numel(healthy),1),ones(numel(healthy),1),opts);
            if flag~=1 || isempty(u) || max(abs(A(off,:)*u))>1e-7
                error('ReconfigEval:HardwareUnknown','硬件能力求解未可靠完成，不能记为零能力。');
            end
            H(k,d)=max(0,s*A(k,:)*u)*ref(k);
        end
    end
end

function [ok,strict,q,info]=probe(a,axis,s,M,faults,p,ref)
    cmd=zeros(6,1); cmd(axis)=s*a;
    [pulse,info]=Thruster_invocation(cmd(1:3),cmd(4:6),M,faults,p);
    q=Pulse_Schedule_Metrics(M,info.schedule,p,cmd,faults);
    ok=q.valid && max(abs(q.pulse-pulse))<=1e-8 && ...
        norm((q.average-cmd)./ref)<=1e-5*norm(cmd./ref) && s*q.average(axis)>1e-8*ref(axis);
    strict=ok && max(q.peak_wrench./ref)<=1e-9;
end

function inv=keepWitness(inv,ok,strict,q,info,a,axis,dir)
    if ~ok, return; end
    inv.axis_callable(axis,dir)=true;
    inv.strict_axis(axis,dir)=inv.strict_axis(axis,dir)||strict;
    inv.axis_min_verified(axis,dir)=min([inv.axis_min_verified(axis,dir),a],[],'omitnan');
    if abs(q.average(axis))>inv.axis_capacity(axis,dir)
        inv.axis_capacity(axis,dir)=abs(q.average(axis));
        inv.axis_witness{axis,dir}=struct('command',info.command,'schedule',info.schedule, ...
            'actual',q.average,'instantaneous_pure',strict);
    end
    inv.uses_impulse_margin_fallback=inv.uses_impulse_margin_fallback||info.uses_impulse_margin_fallback;
end

function value=columnAngle(A)
    A=A(:,vecnorm(A)>1e-12); value=0;
    if size(A,2)<2, return; end
    A=A./vecnorm(A); angles=acos(max(-1,min(1,A'*A)));
    angles(1:size(A,2)+1:end)=Inf; value=min(angles,[],'all');
end

function value=option(s,name,default)
    value=default; if isfield(s,name) && ~isempty(s.(name)), value=s.(name); end
end
