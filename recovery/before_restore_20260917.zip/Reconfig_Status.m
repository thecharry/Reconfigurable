function evaluation = Reconfig_Status(evaluation)
% A score or angle cannot certify directional/command feasibility.
    count=numel(evaluation.FaultSets);
    evaluation.IsReconfig=false(count,1);
    evaluation.Status=repmat("策略12向未证实",count,1);
    if ~isfield(evaluation,'Invocation'), return; end
    for row=1:count
        v=evaluation.Invocation(row);
        evaluation.IsReconfig(row)=v.policy_reconfigurable;
        if v.policy_reconfigurable && v.reference_commands_callable
            evaluation.Status(row)="12向及参考指令通过";
        elseif v.policy_reconfigurable
            evaluation.Status(row)="12向可用；参考指令未全通过";
        elseif isfield(evaluation,'Hardware') && ~evaluation.Hardware(row).reconfigurable
            evaluation.Status(row)="硬件纯轴能力不足";
        end
        if isfield(evaluation,'Score') && ~v.reference_commands_callable
            evaluation.Score(row)=NaN;
        end
    end
end
