function result = Pulse_Schedule_Metrics(matrix, schedule, params, command, faulty)
% Integrate the actual piecewise-constant BODY-frame schedule, not duty guesses.
% First moments imply displacement only in a frozen, linear dynamics model.
    if nargin < 5, faulty = []; end
    n=size(matrix,2); T=params.T;
    if ~isfield(schedule,'intervals') || numel(schedule.intervals)~=n
        error('PulseMetrics:InvalidSchedule','喷气时序与推力器数量不一致。');
    end
    intervals=schedule.intervals; valid=true; events=[0;T]; pulse=zeros(n,1);
    for i=1:n
        q=intervals{i};
        if isempty(q), continue; end
        if size(q,2)~=2 || any(~isfinite(q),'all') || any(q(:,2)<q(:,1))
            error('PulseMetrics:InvalidSchedule','喷气时序必须为有效的起止时间对。');
        end
        q=sortrows(q,1); merged=q(1,:);
        for j=2:size(q,1)
            valid=valid && q(j,1)>=merged(end,2)-1e-9;
            if q(j,1)<=merged(end,2)+1e-10
                merged(end,2)=max(merged(end,2),q(j,2));
            else
                merged(end+1,:)=q(j,:); %#ok<AGROW>
            end
        end
        valid=valid && all(merged(:,1)>=-1e-9 & merged(:,2)<=T+1e-9) && ...
            all(merged(:,2)-merged(:,1)>=params.t_min-1e-9);
        intervals{i}=merged;
        pulse(i)=sum(merged(:,2)-merged(:,1));
        events=[events;merged(:)]; %#ok<AGROW>
    end
    valid=valid && all(pulse(faulty)<=1e-10);
    events=unique([0;T;max(0,min(T,events))]);
    impulse=zeros(6,1); firstMoment=impulse; peak=impulse; prefixPeak=impulse;
    off=abs(command(:))<=1e-12; forcePeak=0; torquePeak=0;
    for j=1:numel(events)-1
        left=events(j); right=events(j+1); mid=(left+right)/2;
        active=false(n,1);
        for i=1:n
            q=intervals{i};
            if ~isempty(q), active(i)=any(q(:,1)<=mid & q(:,2)>mid); end
        end
        wrench=matrix*double(active); dt=right-left;
        impulse=impulse+wrench*dt;
        firstMoment=firstMoment+wrench*dt*(T-mid);
        peak=max(peak,abs(wrench)); prefixPeak=max(prefixPeak,abs(impulse));
        cross=wrench.*off;
        forcePeak=max(forcePeak,norm(cross(1:3)));
        torquePeak=max(torquePeak,norm(cross(4:6)));
    end
    result=struct('valid',valid,'pulse',pulse,'average',impulse/T, ...
        'impulse',impulse,'first_moment',firstMoment,'off_axis',off, ...
        'peak_wrench',peak.*off,'peak_prefix_impulse',prefixPeak.*off, ...
        'end_cross_impulse',impulse.*off,'cross_first_moment',firstMoment.*off, ...
        'peak_cross_force',forcePeak,'peak_cross_torque',torquePeak);
end
